# Validation — 2026-11-16

Passed checks:

- 18 Python unittest cases: actual HTTP requests against a local Supabase protocol
  fixture; invalid credentials, fabricated tokens, refresh, Google PKCE, polling
  secret, one-time delivery, ownership checks for mesh/OBJ/GLB/preview, missing
  configuration and browser-origin rejection.
- WGS84 in metres, concave/closed building geometry, clipping, terrain/UV,
  shared patch seams with a constant DEM fixture, flat-base hill patches with
  zero boundary height, building/roof/water/tree options, OBJ and GLB structure,
  glTF UV orientation, preview resizing, XML fallback and DTD/entity rejection.
- OCR dependency error and fixed-argv Tesseract calls tested with fixtures.
- JavaScript syntax checked with Node.js; all four Ruby files with Prism 2.1.0.
- Importer preflight run in a real Ruby 3.3 WebAssembly VM on a live generated
  mesh: valid data accepted, bad indices/NaN/materials rejected, JPEG dimensions,
  SKP ENU offsets and legacy metadata conversion checked.
- Playwright/Chromium: Email/Google login, invalid login, decimal/DMS input,
  manual/automatic import, OBJ/GLB, theme, WebGL preview/wireframe, responsive
  layout and logout. Native SketchUp bridge/auth responses are fixtures.
- Live public-data build at 10.776889, 106.700806, area 100 x 100 m:
  Esri imagery, Terrarium DEM, OSM fallback; 1,376 triangles (Ground 128,
  Roads_main 10, Roads_local 30, Buildings_lowrise 412, Building_roofs 88,
  Roof_parapets 708). No OSM water/tree objects occurred in this region;
  those layers were checked with fixtures.
- Live-generated GLB passed Khronos glTF Validator: 0 errors, 0 warnings.
- Original reference files preserved byte-for-byte with SHA-256 inventory.
- ZIP/RBZ CRC checked. No .env, caches, node_modules, encrypted vault or native
  runtime binary is bundled in the RBZ.

Requires the operator's environment:

- The user chose to fill Supabase configuration later. Live Email/Google login
  is not tested against their project; .env.example contains no live keys.
- SketchUp Desktop is unavailable. Actual import/textures, placement observers,
  Undo, toolbar and SKP saving need a smoke test in SketchUp 2021 or newer.
  Ruby VM validation does not emulate SketchUp geometry APIs.
- Tesseract was not installed here; OCR subprocess behavior uses fixtures.
- The 8K option, Google tile endpoints and all combinations of roof/terrain
  settings have not received exhaustive live tests. RAM/provider availability
  affect large jobs.
- Overpass was unavailable during the live check; OSM map API fallback worked.
- New runtime is independent. Recovered original reference files retain their
  original rights; encrypted/native MapSKP source and signing keys were not recovered.
